// products.js — catalog data

const PRODUCTS = [
  {
    id: 'p001',
    name: 'Pro Sprint Boot',
    category: 'kubadda-cagta',
    categoryLabel: 'Kubadda Cagta',
    icon: '⚽',
    price: 45,
    description: 'Buudho cayilaanka ah oo ku habboon garoonka cagaaran.'
  },
  {
    id: 'p002',
    name: 'Striker Training Boot',
    category: 'kubadda-cagta',
    categoryLabel: 'Kubadda Cagta',
    icon: '⚽',
    price: 38,
    description: 'Buudho tababarka ah oo adag oo waara.'
  },
  {
    id: 'p003',
    name: 'Ultra Runner X',
    category: 'orinta',
    categoryLabel: 'Orinta',
    icon: '🏃',
    price: 55,
    description: 'Gadhac fudud oo loogu talagalay orinta fog.'
  },
  {
    id: 'p004',
    name: 'Track Racer Pro',
    category: 'orinta',
    categoryLabel: 'Orinta',
    icon: '🏃',
    price: 62,
    description: 'Gadhac tartanka ah oo u xawaaraha dheer.'
  },
  {
    id: 'p005',
    name: 'Court King',
    category: 'koleyga',
    categoryLabel: 'Koleyga',
    icon: '🏀',
    price: 70,
    description: 'Gadhac koleyga oo leh taageero garbaha.'
  },
  {
    id: 'p006',
    name: 'Dunk Force Low',
    category: 'koleyga',
    categoryLabel: 'Koleyga',
    icon: '🏀',
    price: 58,
    description: 'Xawaare iyo xasilloonaan mid ku jira.'
  },
  {
    id: 'p007',
    name: 'Performance Tee',
    category: 'dharka',
    categoryLabel: 'Dharka',
    icon: '👕',
    price: 18,
    description: 'Shaadh ciyaaraha ah oo leh qashin-raridda dhididka.'
  },
  {
    id: 'p008',
    name: 'Pro Shorts',
    category: 'dharka',
    categoryLabel: 'Dharka',
    icon: '🩳',
    price: 22,
    description: 'Suruwal gaaban oo fudud oo u habboon dhammaan ciyaaraha.'
  },
  {
    id: 'p009',
    name: 'Match Football',
    category: 'kubadda-cagta',
    categoryLabel: 'Kubadda Cagta',
    icon: '⚽',
    price: 28,
    description: 'Kubad cayilaanka ah oo heerka tartanka ah.'
  },
  {
    id: 'p010',
    name: 'Grip Socks Pro',
    category: 'dharka',
    categoryLabel: 'Dharka',
    icon: '🧦',
    price: 12,
    description: 'Sharabaadh garbaha ah oo isticmaala tignoolajiyada hoos-qaabka.'
  },
  {
    id: 'p011',
    name: 'Speed Lace Runners',
    category: 'orinta',
    categoryLabel: 'Orinta',
    icon: '🏃',
    price: 48,
    description: 'Gadhac orinta ah oo leh nidaam xidhmo dhaqso.'
  },
  {
    id: 'p012',
    name: 'Slam Dunk High',
    category: 'koleyga',
    categoryLabel: 'Koleyga',
    icon: '🏀',
    price: 75,
    description: 'Gadhac sarreeya oo u habboon ciyaareyaasha isha ku haya meel kasta.'
  }
];
